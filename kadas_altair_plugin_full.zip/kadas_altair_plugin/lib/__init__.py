"""
External dependencies for KADAS Altair plugin.
This directory contains bundled third-party packages.
"""

import sys
import os

# Add lib directory to Python path
lib_path = os.path.dirname(__file__)
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)
