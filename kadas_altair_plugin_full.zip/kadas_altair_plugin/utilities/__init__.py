"""
Utilities module for kadas-altair plugin
"""
